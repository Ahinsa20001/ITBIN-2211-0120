/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author @Ahinsa <your.name at your.org>
 */
public class AddEvent {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/tdlistdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public void addEvent(String eventName,String location,String date) throws SQLException {
        String query = "INSERT INTO event (event_Name, location, date) VALUES (?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            
            statement.setString(1, eventName);
            statement.setString(2, location);
            statement.setString(3, date);
            

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding account: " + e.getMessage());
        }
    }

}
