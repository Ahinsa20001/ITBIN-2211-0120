/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author @Ahinsa <your.name at your.org>
 */
public class RemoveTask {
    public static void removeTask(int taskID) throws SQLException {
        String sql = "DELETE FROM task WHERE task_ID = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, taskID);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No task found with account number: " + taskID);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing task: " + e.getMessage(), e);
        }
    }
}

