/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author @Ahinsa <your.name at your.org>
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddTask {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/tdlistdb";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "";

public void addTask(String tName, String date,String sTime,String eTime,String task) throws SQLException {

String query = "INSERT INTO task (task_Name,date, start_Time, end_Time,task) VALUES (?, ?, ?, ?, ?)";

try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, tName);
            statement.setString(2, date);
            statement.setString(3, sTime);
            statement.setString(4, eTime);
            statement.setString(5, task);

            statement.executeUpdate();
} catch (SQLException e) {
throw new SQLException("Error adding Task: " + e.getMessage());
}
}
}
