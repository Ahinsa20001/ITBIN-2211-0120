/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.AddEvent;
import model.RemoveEvent;

/**
 *
 * @author @Ahinsa <your.name at your.org>
 */
public class EventController {
    public static void addEvent(String eventName,String location,String date)
                 throws SQLException { 
        AddEvent addEvent = new AddEvent();
        addEvent.addEvent(eventName, location, date);
    }
    public void removeEvent(int eventID) throws SQLException {
        RemoveEvent.removeEvent(eventID);
    }


}
