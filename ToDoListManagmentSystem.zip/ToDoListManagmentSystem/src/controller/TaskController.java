/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author @Ahinsa <your.name at your.org>
 */
import model.AddTask;
import java.sql.SQLException;
import model.RemoveTask;

public class TaskController {
    public static void AddTask(String tName, String date,String sTime,String eTime,String task) throws SQLException {
    AddTask addTask = new AddTask();
    addTask.addTask (tName, date, sTime, eTime, task);
    }

    public void removeTask(int taskID) throws SQLException {
        RemoveTask.removeTask(taskID);
        //To change body of generated methods, choose Tools | Templates.
    }

   
}
